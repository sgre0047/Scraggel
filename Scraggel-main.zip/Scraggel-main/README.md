# Scraggel
Scraggel is a forest dwelling monster born from failed lab experiments. Once a harmless, bunny like creature from a magical forest, it was twisted into a nightmare by years of chemical testing. 
